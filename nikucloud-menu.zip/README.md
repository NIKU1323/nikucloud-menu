# NikuCloud VPN Menu

Script bash menu manajemen akun VPN (SSH, VMESS, VLESS, TROJAN, dll) untuk server Xray.

## 📦 Fitur
- Manajemen akun SSH, Xray (VMESS/VLESS/TROJAN)
- SlowDNS & WebSocket support
- Auto SSL Let's Encrypt
- QR Code generator
- Perpanjang akun + monitoring

## 🚀 Cara Install (VPS)
```bash
wget -O install.sh https://raw.githubusercontent.com/NIKU1323/nikucloud-menu/main/install.sh && bash install.sh
```

## 👤 Author
`NIKU1323` - puputjaya883@gmail.com
